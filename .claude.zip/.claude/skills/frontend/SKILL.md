---
name: frontend-code
description: Next.js (App Router) / React / TypeScript / shadcn/ui でフロントエンド実装・リファクタリングを行うときに使用する。コンポーネント実装、Server Actions、API 呼び出し、フォーム (react-hook-form + zod)、テスト (Jest / RTL / Cypress)、Storybook 追加などフロント関連タスク全般が対象。Windows + WSL2 + Docker 環境前提。
---

## 技術スタック

| カテゴリ | ライブラリ / ツール |
|---|---|
| フレームワーク | Next.js (App Router), React, TypeScript |
| UI | shadcn/ui, TailwindCSS, lucide-react, cva |
| フォーム | react-hook-form, zod |
| 状態管理 | zustand |
| 認証 | next-auth |
| データ取得 | fetch, TanStack Query |
| テスト | Jest, React Testing Library, Cypress |
| ドキュメント | Storybook |
| その他 | react-hot-toast |

---

## ディレクトリ構造

```frontend/
├── app/                          # ルーティング専用 (page, layout, loading, error)
│   ├── (auth)/
│   │   ├── login/
│   │   └── register/
│   ├── (authenticated)/
│   │   ├── tasks/
│   │   ├── projects/
│   │   └── layout.tsx
│   ├── api/                      # Route Handlers (必要な場合のみ)
│   ├── layout.tsx
│   └── page.tsx
│
├── components/
│   ├── ui/                       # shadcn/ui (自動生成先)
│   └── shared/                   # プロジェクト横断の自作共通コンポーネント
│       ├── header.tsx
│       ├── header.test.tsx
│       └── header.stories.tsx
│
├── features/                     # ドメインごとの機能 (コロケーション)
│   └── task/
│       ├── schemas/
│       │   └── task.schema.ts    # zod schema + 型定義
│       ├── api/
│       │   ├── get-tasks.ts
│       │   └── create-task.ts
│       ├── components/
│       │   ├── task-list.tsx
│       │   ├── task-list.test.tsx
│       │   ├── task-list.stories.tsx
│       │   ├── task-card.tsx
│       │   └── task-form.tsx
│       ├── hooks/
│       │   └── use-task-filter.ts
│       └── stores/
│           └── use-task-ui-store.ts
│
├── hooks/                        # 横断的なカスタムフックのみ
│   └── use-media-query.ts
│
├── lib/                          # 横断的なユーティリティ / クライアント
│   ├── api/
│   │   └── api-fetch.ts          # 共通 fetch ラッパー
│   ├── auth.ts                   # next-auth 設定
│   └── utils.ts
│
├── providers/                    # Context Providers
│   └── query-provider.tsx
│
├── stores/                       # 横断的な zustand store
│   └── use-sidebar-store.ts
│
├── styles/
│   └── globals.css
│
├── types/                        # グローバル型拡張のみ
│   ├── global.d.ts
│   └── next-auth.d.ts
│
├── tests/
│   └── e2e/                      # Cypress (E2E のみ独立)
│
└── public/

```

### ファイル配置の原則

- **コロケーション優先**: テスト (`.test.tsx`) と Storybook (`.stories.tsx`) はコンポーネントと同じディレクトリに配置する。E2E テストのみ `tests/e2e/` に独立させる。
- **ドメイン固有は `features/{domain}/` に集約**: コンポーネント・フック・store・schema・API 層すべてをドメインディレクトリ内に置く。ルート直下の `hooks/` `lib/` `stores/` は**横断的なもの専用**。
- **共通コンポーネントは `components/` 直下**: `components/ui/` は shadcn/ui の自動生成先、`components/shared/` はプロジェクト横断の自作コンポーネント。`app/` 配下にコンポーネントを置かない。
- **型定義はコロケーション**: zod schema からの `z.infer` を基本とし、`features/{domain}/schemas/` に配置する。ルート直下の `types/` は `global.d.ts` / `next-auth.d.ts` など環境拡張のみに限定する。
- **`app/` はルーティング専用**: `page.tsx` / `layout.tsx` / `loading.tsx` / `error.tsx` / `not-found.tsx` / Route Groups `(xxx)` のみを配置する。ビジネスロジックは `features/` に置く。

---

## 実装方針

### 設計

- **単一責任**: コンポーネントの責任範囲を明確にする。1 ファイル = 1 主要コンポーネント。
- **DDD**: `features/` 配下はドメイン単位で分割する。
- **型設計**: Props・内部状態のインターフェースを厳密に定義する。`any` 型は禁止。

### Rendering Strategy

- **Server First**: 可能な限り Server Components (RSC) で実装し、クライアントへ送る JS 量を削減する。
- **Client Component の局所化**: Hooks / ブラウザ API が必要な箇所のみ `"use client"` を付与し、最小単位で切り出す。

### パフォーマンス

- `useCallback`: 子コンポーネントへ渡す関数・依存配列に含まれる関数は必ずラップする。
- `memo` / `useMemo`: リストアイテム等で再レンダリングが問題になる箇所に適用する。
- `useEffect` の乱用を避け、イベントハンドラ・`useMemo`・Server Actions で代替できないか検討する。

### コーディング規約

- 命名: コンポーネント = `PascalCase`、定数 = `UPPER_SNAKE_CASE`
- Magic string / number は禁止。すべて定数として定義する。
- UI 実装は shadcn/ui を優先する。

### インポート順序

1. React 関連
2. 外部ライブラリ (`zod`, `lucide-react` など)
3. UI コンポーネント (`@/components/ui/...`)
4. Hooks / Utils / API (`@/lib/...`, `@/hooks/...`)

---

## 状態管理

状態は以下の 4 種類に分類し、それぞれ適切な方法で管理する。**zustand の乱用を避ける**ことが最優先。

| 状態の種類 | 例 | 管理方法 |
|---|---|---|
| **サーバー状態** | タスク一覧、ユーザー情報、プロジェクト詳細 | Server Components + Server Actions + `revalidatePath` |
| **URL 状態** | フィルタ条件、ソート順、ページ番号、モーダル開閉 | `searchParams` / `useSearchParams` |
| **ローカル UI 状態** | フォーム入力値、トグル状態、アコーディオン開閉 | `useState` / react-hook-form |
| **グローバル UI 状態** | サイドバー開閉、テーマ、通知キュー、現在のチーム選択 | zustand |

### zustand を使うべきでないケース

- ❌ API から取得したデータ (→ Server Components で取得する)
- ❌ フォームの入力値 (→ react-hook-form で管理する)
- ❌ 1 コンポーネント内で完結する状態 (→ `useState` で十分)
- ❌ ページ間で共有したいフィルタ条件 (→ URL の `searchParams` を使う。リロード・共有・戻る操作に強いため)

### zustand を使うべきケース

- ✅ 複数の離れたコンポーネントで共有する UI 状態 (サイドバー開閉など)
- ✅ リアルタイム性が高く URL に載せたくない状態 (通知キュー・一時的なトースト)
- ✅ ユーザーのセッション単位で保持したい設定 (現在選択中のチーム ID など)

### store の配置と命名

- **配置**: `features/{domain}/stores/` または横断的なものは `stores/` 直下
- **命名**: `use{Purpose}Store` (例: `useSidebarStore`, `useCurrentTeamStore`)
- **1 store = 1 責務**。巨大な単一 store は禁止。ドメインごと・関心ごとに分割する。
- **selector で購読範囲を絞る**。コンポーネントは必要な state のみ購読し、不要な再レンダリングを防ぐ。

```ts
// stores/use-sidebar-store.ts
import { create } from 'zustand';

type SidebarStore = {
  isOpen: boolean;
  toggle: () => void;
  close: () => void;
};

export const useSidebarStore = create((set) => ({
  isOpen: true,
  toggle: () => set((s) => ({ isOpen: !s.isOpen })),
  close: () => set({ isOpen: false }),
}));

// 使用側: selector で必要な部分のみ購読
const isOpen = useSidebarStore((s) => s.isOpen);
```

### persist ミドルウェアの使用基準

- `localStorage` に保存するのは「ユーザー設定」レベルの情報のみ (サイドバー開閉状態、テーマなど)。
- 認証トークン・個人情報・機密情報は `persist` で保存しない。
- SSR との hydration mismatch を避けるため、persist された store を使うコンポーネントは `"use client"` 配下に限定する。

---

## 機能新規作成フロー

`features/{domain}/` 配下に新しい機能を追加する場合、以下の順序で作業する。

1. **型定義 & zod schema 作成** — `features/{domain}/schemas/` に zod schema を定義し、`z.infer<typeof schema>` で型を導出する。バックエンドの API レスポンス構造と一致させる。
2. **API 層の実装** — `features/{domain}/api/` に Server Actions または fetch ラッパーを配置する。Server Actions を第一選択とする。
3. **Server Component の実装** — `features/{domain}/components/` に一覧・詳細などの Server Component を作成する。データ取得は Server Component 内で完結させる。
4. **Client Component の切り出し** — インタラクション (フォーム・モーダル・DnD など) が必要な部分のみ `"use client"` を付与して最小単位で切り出す。Server Component から props 経由でデータを受け取る。
5. **ページへの組み込み** — `app/(routes)/{path}/page.tsx` から features 配下のコンポーネントを呼び出す。`page.tsx` は薄く保ち、ロジックは置かない。
6. **Storybook 追加** — `stories/` に主要コンポーネントのストーリーを追加する。Props の主要パターン (正常・ローディング・空・エラー) を網羅する。
7. **ユニットテスト追加** — `tests/unit/` に Jest + RTL でテストを追加する。ユーザーインタラクションは `@testing-library/user-event` を使用する。
8. **E2E テスト追加 (重要フローのみ)** — タスク作成・編集・削除など業務上クリティカルな操作は `tests/e2e/` に Cypress シナリオを追加する。

### ディレクトリ配置例

```
features/
└── task/
    ├── schemas/
    │   └── task.schema.ts      # zod schema + 型
    ├── api/
    │   ├── get-tasks.ts        # Server Actions (取得)
    │   └── create-task.ts      # Server Actions (作成)
    ├── components/
    │   ├── task-list.tsx       # Server Component
    │   ├── task-card.tsx       # Server Component
    │   └── task-form.tsx       # Client Component
    ├── hooks/
    │   └── use-task-filter.ts  # 必要な場合のみ
    └── stores/
        └── use-task-ui-store.ts # 必要な場合のみ
```

### 新規 page.tsx のひな形

```tsx
// app/(authenticated)/tasks/page.tsx
import { Suspense } from 'react';
import { TaskList } from '@/features/task/components/task-list';
import { TaskListSkeleton } from '@/features/task/components/task-list-skeleton';

export default function TasksPage() {
  return (
    <Suspense fallback={<TaskListSkeleton />}>
      <TaskList />
    </Suspense>
  );
}
```

### UI 状態の取り扱い

| 状態 | 実装方法 |
|---|---|
| ローディング | `loading.tsx` または `<Suspense>` + Skeleton コンポーネント |
| エラー | `error.tsx` (ルートセグメント単位) / `try-catch` + toast |
| 空状態 | `{items.length === 0 ? <EmptyState /> : <List />}` を Server Component で処理 |
| 権限なし | Server Actions / Server Component 内で判定し `notFound()` or `redirect()` |

---

## API 呼び出し

### 基本方針

- データ取得には `fetch` を使用する。
- エンドポイント URL は定数として管理する。
- 認証が必要な場合は next-auth のセッションを使用して認証情報を送信する。
- 取得・更新の使い分けは次節「データ取得・更新の使い分け」に従う。

### データ取得・更新の使い分け

「**サーバー第一・必要なときだけクライアント**」を原則とする。TanStack Query はデフォルト装備ではなく、Server Component / Server Actions だけでは要件を満たせないときに追加する。

#### データ取得

| ケース | 方法 |
|---|---|
| 通常の一覧・詳細表示 | Server Component で `fetch` し、必要なら Client Component に props で渡す |
| ポーリング (通知バッジ、オンライン状態など) | Server Component で初期取得 → `useQuery` に `initialData` として渡す |
| 無限スクロール | `useInfiniteQuery` (初期ページは Server Component で取得し `initialData` に渡す) |
| 検索オートコンプリート・絞り込みの即時反映 | `useQuery` (クライアント操作駆動の fetch) |
| 楽観的更新とセットの再取得 | `useQuery` + `useMutation` + `queryClient.invalidateQueries` |

**原則**:

- 初期表示に必要なデータは必ず Server Component で取得する。クライアントから `useQuery` だけで取得する構成は禁止 (ウォーターフォール・バンドル増・SEO 劣化のため)。
- `useQuery` を使う場合も、Server Component で取得した値を `initialData` に渡して初回レンダリングを即座に行う。
- URL に載せられるフィルタ・ソート・ページ番号は `searchParams` を使い、Server Component 側で再取得する。`useQuery` の引数に持たせない。

#### データ更新

| ケース | 方法 |
|---|---|
| 通常のフォーム送信 (作成・編集・削除) | `useActionState` + Server Actions |
| 楽観的更新が必要な操作 (D&D・トグル・並び替え) | `useMutation` + `onMutate` による楽観的更新 |
| リアルタイム性が求められる操作 (チェックボックス即時反映など) | `useMutation` |

**原則**:

- サーバーへの単純な送信は Server Actions を使う。CSRF 保護・Progressive Enhancement・`revalidatePath` によるキャッシュ無効化を享受できるため。
- UX 上、サーバー応答を待てない操作のみ `useMutation` + 楽観的更新を使う。
- 両者を混在させる画面では、キャッシュ整合性のため **Server Actions 側は `revalidatePath` / `revalidateTag`**、**`useMutation` 側は `queryClient.invalidateQueries`** を必ず呼ぶ。

#### 判断フローチャート

```
[データ取得]
ポーリング / 無限スクロール / 楽観的更新 / クライアント操作駆動の再取得 が必要?
├─ いいえ → Server Component で取得し Client に props で渡す
└─ はい   → Server Component で初期取得 → initialData として useQuery に渡す

[データ更新]
UX 上、サーバー応答を待たずに即座に UI 反映する必要がある?
├─ いいえ → useActionState + Server Actions
└─ はい   → useMutation + onMutate (楽観的更新)
```

#### 実装例: Server で取得 → Client で表示

```tsx
// app/(authenticated)/tasks/page.tsx  (Server Component)
import { getTasks } from '@/features/task/api/get-tasks';
import { TaskBoard } from '@/features/task/components/task-board';

export default async function TasksPage() {
  const tasks = await getTasks();
  return <TaskBoard initialTasks={tasks} />;
}
```

```tsx
// features/task/components/task-board.tsx  (Client Component)
'use client';

import { useState } from 'react';
import type { Task } from '../schemas/task.schema';

type Props = { initialTasks: Task[] };

export function TaskBoard({ initialTasks }: Props) {
  const [tasks, setTasks] = useState(initialTasks);
  // D&D・フィルタなどのインタラクションのみ Client 側で処理
  return {/* ... */};
}
```

#### 実装例: Server で取得 → useQuery でポーリング

```tsx
// features/notification/components/notification-badge.tsx
'use client';

import { useQuery } from '@tanstack/react-query';
import { fetchUnreadCount } from '../api/fetch-unread-count';

type Props = { initialCount: number };

export function NotificationBadge({ initialCount }: Props) {
  const { data } = useQuery({
    queryKey: ['notifications', 'unread-count'],
    queryFn: fetchUnreadCount,
    initialData: initialCount,
    staleTime: 30_000,
    refetchInterval: 30_000, // 30 秒ごとに再取得
  });

  return {data};
}
```

### Server Actions 実装ルール

Server Actions の返り値を直接 UI に反映する。`useState` / `useEffect` / `useReducer` での管理は禁止。

| 処理 | 方針 |
|---|---|
| 状態管理 | Server Actions の返り値をそのまま使用 |
| ローディング | `useTransition` / `isPending` で管理 |
| エラーハンドリング | `try-catch` で実装。エラー時は空配列やフォールバック値を返し UI を保護 |
| ユーザーフィードバック | 成功・エラーメッセージを返り値から表示 |
| リダイレクト | `redirect()` を Server Actions 内で呼び出す |
| フォームリセット | 返り値を受けてクライアント側でリセット処理 |
| データ更新 / キャッシュ | `revalidatePath` / `revalidateTag` で再検証 |
| セキュリティ | Next.js 標準の CSRF 保護を享受 (→ [CSRF 対策](#csrf-対策) 参照) |
| パフォーマンス | Streaming / Suspense を活用してプリフェッチ・段階的表示を行う |

### タイムアウト

**Server Actions / SSR (`fetch` 直接使用)**

`AbortController` を使用してタイムアウトを設定する (推奨: 10 秒)。

```ts
const controller = new AbortController();
const timeoutId = setTimeout(() => controller.abort(), 10_000);
const res = await fetch(url, { signal: controller.signal });
clearTimeout(timeoutId);
```

**CSR (TanStack Query)**

`queryFn` 内で `AbortController` を使用し、10 秒でタイムアウトする。

```ts
useQuery({
  queryFn: async ({ signal }) => {
    const timeoutId = setTimeout(() => signal?.throwIfAborted(), 10_000);
    try {
      const res = await fetch(url, { signal });
      return res.json();
    } finally {
      clearTimeout(timeoutId);
    }
  },
});
```

### リトライ

**Server Actions / SSR (`fetch` 直接使用)**

- ネットワークエラー・5xx 系エラーは最大 3 回リトライする。
- リトライ間隔は指数バックオフ (1 秒 → 2 秒 → 4 秒) を使用する。
- 4xx 系エラーはリトライしない。

**CSR (TanStack Query)**

TanStack Query の `retry` オプションを使用する (自前実装不要)。4xx 系エラーはリトライしない。

```ts
useQuery({
  queryFn: fetchData,
  retry: 3,
  retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 4000),
  retryOnMount: false,
});
```

### レスポンスの型チェック

- API レスポンスは必ず zod でバリデーションし、型安全を保証する。
- バリデーション失敗時はエラーログを出力し、空配列または安全なフォールバック値を返す。

```ts
const schema = z.object({ /* ... */ });
const parsed = schema.safeParse(await res.json());
if (!parsed.success) {
  logger.error(parsed.error);
  return [];
}
```

### ヘッダーの設定

- `Content-Type: application/json` を常に付与する。
- 認証が必要なエンドポイントは `Authorization: Bearer <token>` を付与する。
- セキュリティヘッダー (`X-Request-ID` など) は共通 fetch ラッパーで一元管理する。

```ts
const headers: HeadersInit = {
  'Content-Type': 'application/json',
  ...(token && { Authorization: `Bearer ${token}` }),
};
```

### キャッシュ

- **SSR / ISR**: `fetch` に `{ next: { revalidate: 60 } }` を設定する。
- **CSR**: TanStack Query の `staleTime` を 60,000ms に設定する。Server Component で取得した値を `initialData` として渡す。

---

## フォーム実装

フォームは **react-hook-form + zod + Server Actions** の組み合わせを標準とする。zod schema は 1 つだけ定義し、**クライアントバリデーションと Server Actions のバリデーションで共通利用する**。

### 実装フロー

1. **zod schema を定義** — `features/{domain}/schemas/` に配置。エラーメッセージは日本語で記述する。
2. **型を導出** — `type TaskFormInput = z.infer<typeof taskFormSchema>`
3. **Server Actions を実装** — schema で `safeParse` してから Service 層を呼ぶ。
4. **Client Component でフォームを実装** — `useForm` + `zodResolver` + `useActionState` (React 19) を組み合わせる。
5. **送信中の UI 制御** — `useActionState` の `isPending` でボタンを disable する。
6. **成功・失敗フィードバック** — `react-hot-toast` でユーザーに通知する。

### zod schema の例

```ts
// features/task/schemas/task.schema.ts
import { z } from 'zod';

export const taskFormSchema = z.object({
  title: z.string().min(1, 'タイトルは必須です').max(100, '100 文字以内で入力してください'),
  estimatedHours: z
    .number()
    .min(0, '0 以上で入力してください')
    .multipleOf(0.5, '0.5 時間単位で入力してください'),
  assigneeId: z.string().uuid().nullable(),
  dueDate: z.string().datetime().nullable(),
});

export type TaskFormInput = z.infer;
```

### Server Actions の例

```ts
// features/task/api/create-task.ts
'use server';

import { revalidatePath } from 'next/cache';
import { auth } from '@/lib/auth';
import { apiFetch } from '@/lib/api/api-fetch';
import { taskFormSchema, type TaskFormInput } from '../schemas/task.schema';

type ActionResult =
  | { success: true; message: string }
  | { success: false; errors: Partial<Record> };

export async function createTaskAction(
  _prevState: ActionResult | null,
  formData: FormData,
): Promise {
  const session = await auth();
  if (!session) {
    return { success: false, errors: { title: ['認証が必要です'] } };
  }

  const parsed = taskFormSchema.safeParse({
    title: formData.get('title'),
    estimatedHours: Number(formData.get('estimatedHours')),
    assigneeId: formData.get('assigneeId') || null,
    dueDate: formData.get('dueDate') || null,
  });

  if (!parsed.success) {
    return { success: false, errors: parsed.error.flatten().fieldErrors };
  }

  try {
    await apiFetch('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(parsed.data),
    });
    revalidatePath('/tasks');
    return { success: true, message: 'タスクを作成しました' };
  } catch {
    return { success: false, errors: { title: ['作成に失敗しました'] } };
  }
}
```

### Client Component の例

```tsx
// features/task/components/task-form.tsx
'use client';

import { useActionState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import toast from 'react-hot-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { taskFormSchema, type TaskFormInput } from '../schemas/task.schema';
import { createTaskAction } from '../api/create-task';

export function TaskForm() {
  const [state, formAction, isPending] = useActionState(createTaskAction, null);

  const {
    register,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(taskFormSchema),
    mode: 'onBlur',
  });

  if (state?.success) {
    toast.success(state.message);
  }

  return (
      {errors.title && {errors.title.message}}
      {state && !state.success && state.errors.title && (
        {state.errors.title[0]}
      )}
      {isPending ? '作成中...' : '作成'}
  );
}
```

### フォーム実装のルール

- **zod schema は単一ソース**。フロントエンドとサーバーで同じ schema を import する。重複定義は禁止。
- **エラー表示は 2 系統**: クライアントバリデーション (`errors.xxx.message`) と Server Actions の返り値 (`state.errors.xxx`) の両方を表示する。
- **送信中は必ず disabled**。二重送信を防ぐため `isPending` でボタンを無効化する。
- **`useState` でフォーム値を管理しない**。react-hook-form または `FormData` に一元化する。
- **成功時のリダイレクト**は Server Actions 内で `redirect()` を呼ぶ。クライアント側の `useEffect` で遷移させない。

---

## テスト

| レイヤー | ツール | 対象 |
|---|---|---|
| ユニット / 統合 | Jest + React Testing Library | レンダリング、ユーザーインタラクション、API モック |
| E2E | Cypress | 実際のユーザー操作フロー |

- コンポーネント実装後は必ず Storybook にストーリーを追加する。

---

## ロギング (サーバーサイド)

Server Actions・API Routes のサーバーサイド処理に適用する。

- **出力先**: ブラウザの `console.log` には機密情報を流さない。サーバーログはファイルに出力する。
- **フォーマット**: `日時 | レベル | メッセージ`
- **ファイル管理**: 日付ごとにファイルを分割し、保存期間は必要最低限とする。
- **機密情報**: ログに DB 接続情報・個人情報・スタックトレースを含めない。
- **開発環境**: `npm run dev` では `console.log` の使用は許容する。

---

## セキュリティ

### XSS 対策

- `dangerouslySetInnerHTML` は原則禁止。使用する場合は `dompurify` でサニタイズ必須。
- `<a>` / `<iframe>` の `src` / `href` に動的値を埋め込む際は `javascript:` プロトコルを検証する。

### 環境変数

- `NEXT_PUBLIC_` はブラウザ露出が許容される非機密情報のみに限定する。
- API キー・DB 接続情報・認証シークレットは Server Components / Server Actions 内でのみ参照する。
- サーバー専用ロジックを含むファイルには `import 'server-only'` を記述する。

### 認証・認可

- クライアント側の「ボタン非表示」は UX のためであり、セキュリティではない。
- Server Actions / API Routes の冒頭で必ず `auth()` セッションによる認可を再実行する。
- 認証が必要なルートは `middleware.ts` で一括管理する。

### CSRF 対策

- **Server Actions を中継として使用**することで Next.js 標準の CSRF 保護を享受する (推奨)。
- API Routes を直接呼ぶ場合は `getCsrfToken()` で `X-CSRF-Token` ヘッダーを付与する。
- Cookie は `SameSite=Lax` を徹底し、CORS は許可 Origin のみを指定する。

### エラーハンドリング

- ユーザー向けメッセージ (toast 等) にはスタックトレース・内部構造を含めない。
- 詳細なエラーはサーバーログのみに記録する。

### 依存関係

- `npm audit` を定期実行して脆弱性を把握する。
- 不要なライブラリは追加しない。セキュリティ関連ライブラリは特に慎重に選定する。